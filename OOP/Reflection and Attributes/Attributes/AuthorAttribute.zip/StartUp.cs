﻿using System;

  
    [Author("Ventci")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {
        Tracker tracker = new Tracker();
        tracker.PrintMethodByAuthor();
        }
    }
