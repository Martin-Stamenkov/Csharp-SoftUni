﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
   public class StartUp
    {
        public static void Main(string[] args)
        {
            var count = int.Parse(Console.ReadLine());

            List<Car> cars = new List<Car>();

            for (int i = 0; i < count; i++)
            {
                var carInfo = Console.ReadLine()
                    .Split(" ");

                var model = carInfo[0];
                var fuelAmount = double.Parse(carInfo[1]);          // количетво гориво
                var fuelConsumption = double.Parse(carInfo[2]);     // разход за 1 километър

                Car car = new Car(model, fuelAmount, fuelConsumption);

                cars.Add(car);
         
            }

            var command = Console.ReadLine();

            while (command !="End")
            {
                var info = command.Split(" ");

                var carModel = info[1];
                var amountKm = double.Parse(info[2]);  //количество километри

                foreach (var car in cars)
                {
                    if (car.Model == carModel)
                    {
                        car.CalculateDistanceOrNot(amountKm);
                    }

                }
                command = Console.ReadLine();
            }

            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}");
            }

        }

    }
}
