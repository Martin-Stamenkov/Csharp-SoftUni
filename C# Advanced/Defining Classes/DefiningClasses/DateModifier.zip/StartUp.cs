﻿using System;

namespace DefiningClasses
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            DateModifier date = new DateModifier();

            string firstDade = Console.ReadLine();
            string secondDade = Console.ReadLine();

            date.DifferenceBetweenTwoDates(firstDade,secondDade);
        }
    }
}
